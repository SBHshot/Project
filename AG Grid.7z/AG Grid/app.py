
import json
import os
import pymssql
import pandas as pd
from flask_pagination import Pagination
from flask import Flask, render_template, Request, request, redirect, url_for
from flask_cors import CORS, cross_origin
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine, inspect, text
from unicodedata import name
from sqlite3 import connect
from msilib.schema import tables
from http import server
from cgi import test
from cProfile import label

app = Flask(__name__)
CORS(app, supports_credentials=True)
engine = create_engine(
    'mssql+pymssql://mtbtestee:Aa12366@@TAWSQLDBA01\TAMSSDBA01/MTB_TEST_EE')
DBSession = sessionmaker(bind=engine)
# Global variable
record = {}


@app.route('/', methods=['GET', 'POST'])
@cross_origin(supports_credentials=True)
def home():
    db_query = 'select * from PM_calendar_rawdata WITH (NOLOCK)'
    test_query = 'select * from test WITH (NOLOCK)'
    inspector = inspect(engine)
    db_result = pd.read_sql(db_query, engine).drop_duplicates()
    db_result["NOTE"] = ""
    db_result.to_sql('test', engine, if_exists='replace', index=False)
    test_result = pd.read_sql(test_query, engine)
    test_result.index += 1
    print(test_result)
    # timestamp處理,避免出現太多0
    test_result['Due_Date'] = test_result['Due_Date'].astype(str)
    test_result['Suggest_Date'] = test_result['Suggest_Date'].astype(str)
    if request.method == 'GET':
        return test_result.to_json(orient='index')


if __name__ == "__main__":  # 如果以主程式執行
    app.run()  # 立刻啟動伺服器
