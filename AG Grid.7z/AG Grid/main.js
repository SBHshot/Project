

function create_table() {
  $("#myGrid").html("");

  gridOptions = {
    rowData: getData(),
    columnDefs: [
      { field: 'name' },
      { field: 'medals.gold', headerName: 'Gold' },
      { field: 'person.age' },
    ],
  };

  //Set Grid
  new agGrid.Grid(document.querySelector('#myGrid'), gridOptions);
}

$(document).ready(function () {
  $.ajax({
    url: '127.0.0.1:5000',
    type: 'GET',
    dataType: 'jsonp',
    headers: {
      'Access-Control-Allow-Origin': "*"
    },
    withCredentials: true,
    crossDomain: true,
    success: function () {
      alert("success");
    },
    error: function () {
      alert("Error");
    }
  });
})