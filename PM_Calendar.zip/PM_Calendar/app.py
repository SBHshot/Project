from email import header
from unittest import result
from flask import Flask, render_template, Request, request, redirect, url_for
import json
import pandas as pd
import os
app = Flask(__name__)
# Global variable
record = {}


@app.route('/', methods=['GET', 'POST'])
def index():
    df = pd.read_csv('raw.csv', index_col=0)
    df.fillna(value="", inplace=True)
    # timestamp處理,避免出現太多0
    df['Due_Date'] = df['Due_Date'].astype(str)
    df['Suggest_Date'] = df['Suggest_Date'].astype(str)
    # 將dataframe標題儲存成tuple
    # for <thead>
    heading = list(df)
    heading.insert(0, '')
    # heading = tuple(heading)
    # 儲存dataframe內容
    # for <tbody>
    content = list(df.to_records())
    # content = tuple(content)
    return render_template('index.html', contents=content, headings=heading)


# app的路由地址"/submit"即為ajax中定義的url地址，采用POST、GET方法均可提交
@app.route("/submit", methods=["GET", "POST"])
# 從這里定義具體的函式 回傳值均為json格式
def submit():
    # 由于POST、GET獲取資料的方式不同，需要使用if陳述句進行判斷
    if request.method == "POST":
        # 從前端拿數據
        #data = request.get_json()
        result = request.form.to_dict()
        for key in result.keys():
            record = key

    json_df = pd.read_json(record, orient='index')

    fileName = "history.csv"
    if os.path.exists(fileName):
        print("file exist")
        if os.path.getsize(fileName):
            print("file is not null!")
            json_df.to_csv(fileName, mode='a', header=False, index=False)
        else:
            print("empty")
            json_df.to_csv(fileName, index=False)

    else:
        print("file not exist")
        json_df.to_csv(fileName)

    if len(result) == 0:
        # 回傳的形式為 json (result)
        return {'message': "error!"}
    else:
        return {'message': "success!"}


@app.route('/record')
def record():
    csv_df = pd.read_csv('history.csv', index_col=False)
    print(csv_df)
    # csv_df.insert(0, "")
    heading = list(csv_df)
    heading.insert(0, '')
    content = list(csv_df.to_records())
    print(heading)
    return render_template('record.html', contents=content, headings=heading)


if __name__ == "__main__":  # 如果以主程式執行
    app.run()  # 立刻啟動伺服器
