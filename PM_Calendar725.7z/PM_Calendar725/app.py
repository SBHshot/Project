from cProfile import label
from cgi import test
from http import server
from msilib.schema import tables
from sqlite3 import connect
from unicodedata import name
from sqlalchemy import create_engine, inspect, text
from sqlalchemy.orm import sessionmaker
from flask import Flask, render_template, Request, request, redirect, url_for
from flask_pagination import Pagination
import pandas as pd
import pymssql
import os
import json
import db

app = Flask(__name__)

engine = create_engine(
    'mssql+pymssql://mtbtestee:Aa12366@@TAWSQLDBA01\TAMSSDBA01/MTB_TEST_EE')
DBSession = sessionmaker(bind=engine)
# Global variable
record = {}


@app.route('/', methods=['GET', 'POST'])
def home():
    db_query = 'select * from PM_calendar_rawdata WITH (NOLOCK)'
    test_query = 'select * from test WITH (NOLOCK)'
    inspector = inspect(engine)
    db_result = pd.read_sql(db_query, engine).drop_duplicates()
    db_result["NOTE"] = ""
    db_result.to_sql('test', engine, if_exists='replace', index=False)
    test_result = pd.read_sql(test_query, engine)
    # timestamp處理,避免出現太多0
    test_result['Due_Date'] = test_result['Due_Date'].astype(str)
    test_result['Suggest_Date'] = test_result['Suggest_Date'].astype(str)
    # 將dataframe標題儲存成tuple
    # for <thead>
    heading = list(test_result)
    heading.insert(0, '')
    # 儲存dataframe內容
    # for <tbody>
    content = list(test_result.to_records())
    return render_template('index.html', headings=heading, contents=content)
# app的路由地址"/submit"即為ajax中定義的url地址，采用POST、GET方法均可提交


@app.route("/submit", methods=["GET", "POST"])
# 從這里定義具體的函式 回傳值均為json格式
def submit():
    # 由于POST、GET獲取資料的方式不同，需要使用if陳述句進行判斷
    if request.method == "POST":
        # 從前端拿數據
        #data = request.get_json()
        result = request.form.to_dict()
        for key in result.keys():
            record = key

    json_df = pd.read_json(record, orient='index')
    json_df.to_sql('PM_Calendar_Record', engine,
                   if_exists="append", index=False)

    if len(result) == 0:
        # 回傳的形式為 json (result)
        return {'message': "error!"}
    else:
        return {'message': "success!"}


@app.route('/record')
def record():
    record_query = 'select * from PM_Calendar_Record WITH (NOLOCK)'
    record_df = pd.read_sql(record_query, engine)
    # csv_df.insert(0, "")
    heading = list(record_df)
    heading.insert(0, '')
    content = list(record_df.to_records())
    print(heading)
    return render_template('record.html', contents=content, headings=heading)


if __name__ == "__main__":  # 如果以主程式執行
    app.run()  # 立刻啟動伺服器
