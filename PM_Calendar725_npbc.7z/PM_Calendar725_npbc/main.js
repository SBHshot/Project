$(function () {
    //儲存每次操作的內容
    var selectedData = new Array();
    var savedData = new Array();
    //add timestamp
    var savedDataWithTimeStamp = new Array();
    var savedDataWithTimeStampToDict = {};
    var savedDataWithTimeStampToDictList = [];
    var unfoldedArray = []
    // 欲提交的資料
    var submitData = [];
    var newRowData = new Array();
    var title = ['origin_index', 'Ball_Count', 'PKG_Dimension', 'PKG_Height', 'RTD_SETUP', 'tester', 'equip_id', 'Due_Date', 'Suggest_Date', 'Last_PM', 'Event_Code', 'Code', 'Semi_State_ID', 'Standard_work_time', 'Location', 'Status', 'PM_duration', 'Type', 'Freq', 'Cur', 'Due', 'warning', 'critical', 'handler', 'NOTE', 'edit_time']
    console.log("title length")
    console.log(title.length)
    // 每次Save的資料
    var rowItem = {}
    var total = []
    var edit = 0
    var table = $('#myTable').DataTable({
        //stateSave: true,
        scrollX: true,
        scrollY: '50vh',
        scrollCollapse: true,
        "pagingType": "full_numbers",
        "language": {
            "oPaginate": {
                "sFirst": "首頁",
                "sLast": "末頁",
                "sPrevious": "上一頁",
                "sNext": "下一頁"
            }
        }
    });

    table.on('order.dt search.dt', function () {
        table.column(0, {
            search: 'applied',
            order: 'applied'
        }).nodes().each(function (cell, i) {
            cell.innerHTML = i + 1;
        });
    }).draw();
    // 選擇欄位
    $('#myTable tbody').on('click', 'tr', function () {
        $(this).toggleClass('selected');
        //if ($(this).hasClass('selected')) {
        //   temp = table.rows('.selected').data()[0].push("sel")
        //    selectedData.push(table.rows('.selected').data()[0])
        //}
    });
    $('#btn_edit').click(function () {
        console.log('edit');
        selectedData = table.rows('.selected').data().toArray()
        //for (let i = 0; i < selectedData.length; i++) {
        //    selectedData[i].shift()
        //}
        console.log(selectedData)
        console.log(selectedData.length)
        //console.log(table.rows('.selected').data().length)
        if (selectedData.length > 0) {  //1
            $("#editInfo").modal()
        } else {
            alert('請選擇欲修改項目.');
        }
        //rowData = table.rows('.selected').data();
        //var inputs = $("#editModal").find('input')
        //在輸入欄位放入原始資料
        //$(inputs[0]).val(rowData[23]) //24
        //console.log(rowData[0])
    });
    $("#editNote").keyup(function () {
        if ($("#editModal").find('input').val() != "") {
            $("#saveEdit").removeAttr("disabled");
        } else {
            $("#saveEdit").attr("disabled", "disabled");
        }
    });
    $('#saveEdit').click(function () {
        const current = new Date()
        timedate = current.toString()
        console.log(timedate)
        var editNote = $("#editNote").val()
        for (var i = 0; i < selectedData.length; i++) {
            len = selectedData[i].length
            selectedData[i][len - 1] = editNote
        }
        console.log(selectedData)
        //save the selected data
        for (var i = 0; i < selectedData.length; i++) {
            savedData.push(selectedData[i])
        }
        //clone array without reference for timestamp
        savedDataWithTimeStamp = JSON.parse(JSON.stringify(savedData))
        //add timestamp
        for (var i = 0; i < savedDataWithTimeStamp.length; i++) {
            savedDataWithTimeStamp[i].push(timedate)
        }
        //savedDataWithTimeStamp convert to dict
        for (var i = 0; i < savedDataWithTimeStamp.length; i++) {
            title.forEach((key, value) => savedDataWithTimeStampToDict[key] = savedDataWithTimeStamp[i][value]);
            savedDataWithTimeStampToDictList.push(savedDataWithTimeStampToDict)
            savedDataWithTimeStampToDict = {}
        }
        console.log("savedDataWithTimeStampToDictList")
        console.log(savedDataWithTimeStampToDictList)
        //unfold the array for inner HTML
        for (var i = 0; i < savedData.length; i++) {
            for (var j = 0; j < savedData[i].length; j++) {
                unfoldedArray.push(savedData[i][j])
            }
        }
        var tds = Array.prototype.slice.call($('.selected td'))
        for (var i = 0; i < unfoldedArray.length; i++) {
            tds[i].innerHTML = unfoldedArray[i];
        }
        console.log("First dictionary:")
        console.log(savedDataWithTimeStampToDictList[0])
        //data for submit
        for (var i = 0; i < savedDataWithTimeStampToDictList.length; i++) {
            var temp = savedDataWithTimeStampToDictList[i]
            submitData = submitData.concat(temp)
            temp = {}
        }
        console.log('SubmitData:')
        console.log(submitData)
        //reset after save
        selectedData = []
        unfoldedArray = []
        savedData = []
        savedDataWithTimeStamp = []
        savedDataWithTimeStampToDict = {}
        savedDataWithTimeStampToDictList = []
        //取消選擇
        table.rows('.selected').nodes().to$().removeClass('selected');

    });
    $('#btn_submit').click(function () {
        if (submitData.length == 0) {
            alert("Nothing changed, can't submit!")
        } else {
            var json = Object.assign({}, submitData);
            console.log(JSON.stringify(json))
            $.ajax({
                url: "submit", /*資料提交到submit處*/
                type: "POST",  /*采用POST方法提交*/
                data: JSON.stringify(json),  /*提交的資料（json格式），從輸入框中獲取*/
                /*result為后端函式回傳的json*/
                success: function (result) {
                    if (result.message == "success!") {
                        alert("Submitted success!")
                        window.location.href = "record"
                    }

                }
            });
        }
        submitData = []
    })
    $("#cancelEdit").click(function () {
        $("#editModal").find('input').val('')
    });
})